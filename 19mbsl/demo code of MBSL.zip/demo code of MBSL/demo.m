clearvars
close all

% Simple vectorizing function
vec = @(x) x(:);

% Normalization of values from 0 - 1
normalize = @(x) (x - min(x(:)))/(max(x(:)) - min(x(:)));

%% Simulation constants
pattype = 'triangle';    			% Pattern type
period = 20; 						% Pattern period in pixels

%% Load data -- Please place Middlebury texture and depth image in this folder
albedo_rgb = imread('albedo.png');

% To simulate error due to albedo and guide mismatch, set albedo and guide
% to different channels
albedo = double(albedo_rgb(:, :, 1))/255;
guide = double(albedo_rgb(:, :, 3))/255;
figure; imshow([albedo guide]) ; 
title('left: albedo, right: guide')

disparity = imread('disparity.png');
disparity_base = normalize(double(disparity));

[H, W] = size(disparity);
[X, Y] = meshgrid(1:W, 1:H);

%% Fix zero values in disparity -- these interfere with simulations
[Xn, Yn] = find(disparity_base ~= 0);
[Xz, Yz] = find(disparity_base == 0);

zero_vals = griddata(Xn, Yn, disparity_base(disparity_base ~= 0), ...
                          Xz, Yz);
disparity_base(disparity_base == 0) = zero_vals;

%% Compute disparity range
max_disparity = period / 8;  
min_disparity = 0;

% Window size can be 1 period or 2 periods for robustness
winsize = [period, period];

% Create pattern
[pat, ~] = get_pattern([H, W], period, pattype); 

% Compute pattern derivative
dx = pat(:,2:end) - pat(:,1:end-1);
dx = [dx dx(:,end)];
        
%% The tip of triangle is not differentiable, so we need to give it
%  zero weight. Please check supplementary for more details.
if strcmp(pattype, 'triangle')
    patOneRow = pat(1,:); ind_val1 = find(patOneRow == 1); ind_val0 = find(patOneRow == 0);
    wtOneRow = ones(1,W); 
    indices = [];
    for i = 0 : ceil(max_disparity)
        indices = [indices ind_val1+i ind_val0+i];
    end
    indices(indices>W) = [];
    wtOneRow(indices) = 0;
    wt = repmat(wtOneRow, H, 1);
else
	wt = ones(H, W);
end

% Now create disparity map
disparity = (max_disparity - min_disparity)*disparity_base + min_disparity;

% Generate scene image
im = interp2(X, Y, pat, X-disparity, Y).*albedo + 0.01*randn(H,W); % also add some noise
        
%% Now compute disparity with MSL algorithm
% MBSL --- the method in the paper, 2*2 matrix, compute albedo and disparity at the same time
[d, a] = msl(im.*wt, pat.*wt, -dx.*wt, winsize, guide);

% MBSL+ --- 2*2 matrix, but compute albedo first, then compute disparity
[d_, a_] = msl_(im.*wt, pat.*wt, -dx.*wt, winsize, guide);

% MBSL++ --- 4*4 matrix, and compute albedo first, then compute disparity
[d_v2, a_v2] = msl_v2(im.*wt, pat.*wt, -dx.*wt, winsize, guide);

figure; imshow([d d_ d_v2 disparity], [0 max_disparity+0.5]); colormap jet(256)
title('disparity map (from left to right: by MBSL, by MSBL+, by MBSL++, ground truth)')

figure; imshow([a a_ a_v2 albedo]); 
title('albedo map (from left to right: by MBSL, by MSBL+, by MBSL++, ground truth)')
        
% confidence map
im_simu = interp2(X, Y, pat, X-d_v2, Y).*a_v2;
cmap = abs(im - im_simu);
figure; imshow(cmap,[0 0.2]); colormap jet
title('confidence map of MBSL++')
      