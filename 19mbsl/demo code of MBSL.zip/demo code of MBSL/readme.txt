If you use this code, please cite this paper
Micro-Baseline Structured Light
Vishwanath Saragadam, Jian Wang, Mohit Gupta, and Shree Nayar
ICCV 2019

If you have any question about the code, please contact
jianwang.cmu@gmail.com
vishwanath.saragadam@rice.edu