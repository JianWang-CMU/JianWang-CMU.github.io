function [disparity, albedo] = msl_(im, pat, dx, winsize, guide)
	% Function to compute disparity from captured image using micro-baseline
	% structured light equation using fast convolutional method.
	%
	% Inputs:
	% 	im: Captured image
	% 	pat: Pattern that was used for capturing image
	% 	dx: Derivative of pattern along x-axis
	% 	winsize: 2-tuple Size of window for solving MSL equation
    %   guide: Image that acts as a proxy for albedo. We assume that the 
    %       albedo is a linear scaling of guide.
	%
	% Outputs:
	% 	disparity: Estimated disparity
    
    % Modify pattern and derivative to look like albedo scaled versions
    pat = pat.*guide;
    dx = dx.*guide;
    
	% Create convolution kernel
	kx = ones(winsize(1), 1, 'single')/winsize(1);
    ky = ones(1, winsize(2), 'single')/winsize(2);

	% Create MSL equation images. We essentially solve the following
    % linear inverse problem at each pixel:
    %   | v11 v12 | | albedo           | = | v1c |
    %   | v12 v22 | | albedo*disparity |   | v2c |
    
	v11_img = conv2(conv2(pat.*pat, kx, 'same'), ky, 'same');
	v12_img = conv2(conv2(pat.*dx, kx, 'same'), ky, 'same');
	v22_img = conv2(conv2(dx.*dx, kx, 'same'), ky, 'same');
    
	v1c_img = conv2(conv2(pat.*im, kx, 'same'), ky, 'same');
	v2c_img = conv2(conv2(dx.*im, kx, 'same'), ky, 'same');
    
    det_img = v11_img.*v22_img - v12_img.*v12_img;

	% Solve for all pixels simultaneously
	albedo = (v22_img.*v1c_img - v12_img.*v2c_img)./det_img;

	% im = albedo .* pat + albedo * dx * disparity
    a = albedo .* dx; b = im - albedo .* pat;
    v11 = boxfilt(a .* a, winsize);
    v1c = boxfilt(a .* b, winsize);
    disparity = v1c ./ v11;

    albedo = albedo .* guide;
end


function imconv = boxfilt(im, bsize)
	% Function to implement separable convolution for box filtering.
	%
	% Inputs:
	% 	im: Image to convolve
	% 	bsize: 2-tuple size of box
	%
	% Outputs:
	% 	imconv: Filtered image.

	if ndims(im) == 2
		im = reshape(im, size(im,1), size(im,2), 1);
	end

	imconv = zeros(size(im));
	for idx = 1:size(im, 3)	
		imconv(:, :, idx) = conv2(im(:, :, idx), ones(1, bsize(2))/bsize(2), ...
	   							  'same');
		imconv(:, :, idx) = conv2(imconv(:, :, idx), ...
								  ones(bsize(1), 1)/bsize(1), 'same');
	end
end

