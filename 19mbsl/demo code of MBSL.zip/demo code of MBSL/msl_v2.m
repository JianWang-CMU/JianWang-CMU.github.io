function [disparity, albedo] = msl_v2(im, pat, dx, winsize, guide)
	% Function to compute disparity from captured image using micro-baseline
	% structured light equation using fast convolutional method.
	%
	% Inputs:
	% 	im: Captured image
	% 	pat: Pattern that was used for capturing image
	% 	dx: Derivative of pattern along x-axis
	% 	winsize: 2-tuple Size of window for solving MSL equation
    %   guide: Image that acts as a proxy for albedo. We assume that the 
    %       albedo is a linear scaling of guide + offset.
    %   Important: "offset" is the difference between msl() and msl_v2()
	%
	% Outputs:
	% 	disparity: Estimated disparity
       
    a = guide .* pat;
    b = pat;
    c = guide .* dx;
    d = dx;
    v11 = boxfilt(a .* a, winsize);
    v12 = boxfilt(a .* b, winsize);
    v13 = boxfilt(a .* c, winsize);
    v14 = boxfilt(a .* d, winsize);
    v21 = v12;
    v22 = boxfilt(b .* b, winsize);
    v23 = boxfilt(b .* c, winsize);
    v24 = boxfilt(b .* d, winsize);
    v31 = v13;
    v32 = v23;
    v33 = boxfilt(c .* c, winsize);
    v34 = boxfilt(c .* d, winsize);
    v41 = v14;
    v42 = v24;
    v43 = v34;
    v44 = boxfilt(d .* d, winsize);

    v1c = boxfilt(a .* im, winsize);
    v2c = boxfilt(b .* im, winsize);
    v3c = boxfilt(c .* im, winsize);
    v4c = boxfilt(d .* im, winsize);
    
% [v11 v12 v13 v14;
%  v21 v22 v23 v24;
%  v31 v32 v33 v34;
%  v41 v42 v43 v44]

    A = cell(4,4);
    A(1,1) = {'v11'}; A(1,2) = {'v12'}; A(1,3) = {'v13'}; A(1,4) = {'v14'}; 
    A(2,1) = {'v21'}; A(2,2) = {'v22'}; A(2,3) = {'v23'}; A(2,4) = {'v24'}; 
    A(3,1) = {'v31'}; A(3,2) = {'v32'}; A(3,3) = {'v33'}; A(3,4) = {'v34'}; 
    A(4,1) = {'v41'}; A(4,2) = {'v42'}; A(4,3) = {'v43'}; A(4,4) = {'v44'}; 
    
    B = [A(2,2) A(2,3) A(2,4);
          A(3,2) A(3,3) A(3,4);
          A(4,2) A(4,3) A(4,4)];
    v11_inverse = eval([char(B(1,1)) '.*' char(B(2,2)) '.*'  char(B(3,3)) '+' ...
                        char(B(1,2)) '.*' char(B(2,3)) '.*'  char(B(3,1)) '+' ...
                        char(B(2,1)) '.*' char(B(3,2)) '.*'  char(B(1,3)) '-' ...
                        char(B(1,3)) '.*' char(B(2,2)) '.*'  char(B(3,1)) '-' ...
                        char(B(2,3)) '.*' char(B(3,2)) '.*'  char(B(1,1)) '-' ...
                        char(B(1,2)) '.*' char(B(2,1)) '.*'  char(B(3,3))]);
                    
    B = [A(2,1) A(2,3) A(2,4);
          A(3,1) A(3,3) A(3,4);
          A(4,1) A(4,3) A(4,4)];
    v12_inverse = -eval([char(B(1,1)) '.*' char(B(2,2)) '.*'  char(B(3,3)) '+' ...
                        char(B(1,2)) '.*' char(B(2,3)) '.*'  char(B(3,1)) '+' ...
                        char(B(2,1)) '.*' char(B(3,2)) '.*'  char(B(1,3)) '-' ...
                        char(B(1,3)) '.*' char(B(2,2)) '.*'  char(B(3,1)) '-' ...
                        char(B(2,3)) '.*' char(B(3,2)) '.*'  char(B(1,1)) '-' ...
                        char(B(1,2)) '.*' char(B(2,1)) '.*'  char(B(3,3))]);
                    
    B = [A(2,1) A(2,2) A(2,4);
          A(3,1) A(3,2) A(3,4);
          A(4,1) A(4,2) A(4,4)];
    v13_inverse = eval([char(B(1,1)) '.*' char(B(2,2)) '.*'  char(B(3,3)) '+' ...
                        char(B(1,2)) '.*' char(B(2,3)) '.*'  char(B(3,1)) '+' ...
                        char(B(2,1)) '.*' char(B(3,2)) '.*'  char(B(1,3)) '-' ...
                        char(B(1,3)) '.*' char(B(2,2)) '.*'  char(B(3,1)) '-' ...
                        char(B(2,3)) '.*' char(B(3,2)) '.*'  char(B(1,1)) '-' ...
                        char(B(1,2)) '.*' char(B(2,1)) '.*'  char(B(3,3))]);
                    
	B = [A(2,1) A(2,2) A(2,3);
          A(3,1) A(3,2) A(3,3);
          A(4,1) A(4,2) A(4,3)];
    v14_inverse = -eval([char(B(1,1)) '.*' char(B(2,2)) '.*'  char(B(3,3)) '+' ...
                        char(B(1,2)) '.*' char(B(2,3)) '.*'  char(B(3,1)) '+' ...
                        char(B(2,1)) '.*' char(B(3,2)) '.*'  char(B(1,3)) '-' ...
                        char(B(1,3)) '.*' char(B(2,2)) '.*'  char(B(3,1)) '-' ...
                        char(B(2,3)) '.*' char(B(3,2)) '.*'  char(B(1,1)) '-' ...
                        char(B(1,2)) '.*' char(B(2,1)) '.*'  char(B(3,3))]);
                    
%     B = [A(1,2) A(1,3) A(1,4);
%           A(3,2) A(3,3) A(3,4);
%           A(4,2) A(4,3) A(4,4)];
%     v21_inverse = -eval([char(B(1,1)) '.*' char(B(2,2)) '.*'  char(B(3,3)) '+' ...
%                         char(B(1,2)) '.*' char(B(2,3)) '.*'  char(B(3,1)) '+' ...
%                         char(B(2,1)) '.*' char(B(3,2)) '.*'  char(B(1,3)) '-' ...
%                         char(B(1,3)) '.*' char(B(2,2)) '.*'  char(B(3,1)) '-' ...
%                         char(B(2,3)) '.*' char(B(3,2)) '.*'  char(B(1,1)) '-' ...
%                         char(B(1,2)) '.*' char(B(2,1)) '.*'  char(B(3,3))]);
    v21_inverse = v12_inverse;
                   
    B = [A(1,1) A(1,3) A(1,4);
          A(3,1) A(3,3) A(3,4);
          A(4,1) A(4,3) A(4,4)];
    v22_inverse = eval([char(B(1,1)) '.*' char(B(2,2)) '.*'  char(B(3,3)) '+' ...
                        char(B(1,2)) '.*' char(B(2,3)) '.*'  char(B(3,1)) '+' ...
                        char(B(2,1)) '.*' char(B(3,2)) '.*'  char(B(1,3)) '-' ...
                        char(B(1,3)) '.*' char(B(2,2)) '.*'  char(B(3,1)) '-' ...
                        char(B(2,3)) '.*' char(B(3,2)) '.*'  char(B(1,1)) '-' ...
                        char(B(1,2)) '.*' char(B(2,1)) '.*'  char(B(3,3))]);
                    
    B = [A(1,1) A(1,2) A(1,4);
          A(3,1) A(3,2) A(3,4);
          A(4,1) A(4,2) A(4,4)];
    v23_inverse = -eval([char(B(1,1)) '.*' char(B(2,2)) '.*'  char(B(3,3)) '+' ...
                        char(B(1,2)) '.*' char(B(2,3)) '.*'  char(B(3,1)) '+' ...
                        char(B(2,1)) '.*' char(B(3,2)) '.*'  char(B(1,3)) '-' ...
                        char(B(1,3)) '.*' char(B(2,2)) '.*'  char(B(3,1)) '-' ...
                        char(B(2,3)) '.*' char(B(3,2)) '.*'  char(B(1,1)) '-' ...
                        char(B(1,2)) '.*' char(B(2,1)) '.*'  char(B(3,3))]);
                    
    B = [A(1,1) A(1,2) A(1,3);
          A(3,1) A(3,2) A(3,3);
          A(4,1) A(4,2) A(4,3)];
    v24_inverse = eval([char(B(1,1)) '.*' char(B(2,2)) '.*'  char(B(3,3)) '+' ...
                        char(B(1,2)) '.*' char(B(2,3)) '.*'  char(B(3,1)) '+' ...
                        char(B(2,1)) '.*' char(B(3,2)) '.*'  char(B(1,3)) '-' ...
                        char(B(1,3)) '.*' char(B(2,2)) '.*'  char(B(3,1)) '-' ...
                        char(B(2,3)) '.*' char(B(3,2)) '.*'  char(B(1,1)) '-' ...
                        char(B(1,2)) '.*' char(B(2,1)) '.*'  char(B(3,3))]);
                    
    det_img = v11.*v11_inverse + v12.*v12_inverse + v13.*v13_inverse + v14.*v14_inverse;
    
    a = (v11_inverse.*v1c + v12_inverse.*v2c + v13_inverse.*v3c + v14_inverse.*v4c) ./ det_img;
    b = (v21_inverse.*v1c + v22_inverse.*v2c + v23_inverse.*v3c + v24_inverse.*v4c) ./ det_img;
                  
    albedo = a.*guide + b;

    % im = albedo .* pat + albedo * dx * disparity
    a = albedo .* dx; b = im - albedo .* pat;
    v11 = boxfilt(a .* a, winsize);
    v1c = boxfilt(a .* b, winsize);
    disparity = v1c ./ v11;
end





function imconv = boxfilt(im, bsize)
	% Function to implement separable convolution for box filtering.
	%
	% Inputs:
	% 	im: Image to convolve
	% 	bsize: 2-tuple size of box
	%
	% Outputs:
	% 	imconv: Filtered image.

	if ndims(im) == 2
		im = reshape(im, size(im,1), size(im,2), 1);
	end

	imconv = zeros(size(im));
	for idx = 1:size(im, 3)	
		imconv(:, :, idx) = conv2(im(:, :, idx), ones(1, bsize(2))/bsize(2), ...
	   							  'same');
		imconv(:, :, idx) = conv2(imconv(:, :, idx), ...
								  ones(bsize(1), 1)/bsize(1), 'same');
	end
end
